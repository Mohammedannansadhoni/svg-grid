create view view_name_2 as
select * from spt_fallback_db
go

