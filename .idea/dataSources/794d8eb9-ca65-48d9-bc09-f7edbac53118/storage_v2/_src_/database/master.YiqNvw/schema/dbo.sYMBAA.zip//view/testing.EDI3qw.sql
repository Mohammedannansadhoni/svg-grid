create view testing as
select * from sys.column_encryption_key_values
go

